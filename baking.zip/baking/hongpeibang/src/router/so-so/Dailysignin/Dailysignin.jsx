import React, {Component, Fragment} from "react";
import {withRouter} from "react-router";

class Dailysignin extends Component {
    constructor() {
        super();
        this.state = {}
    }

    render() {
        return (<Fragment><div>新手教程</div></Fragment>)
    }

}

export default withRouter(Dailysignin);