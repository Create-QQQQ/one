import React, {Component} from "react";

class home extends Component {
    constructor() {
        super();
        this.state = {}
    }

    render() {
        return (<div className={"HEAD"}>
            <img alt={"标本"} src={"https://image.hongbeibang.com/FsxN7RUFRJ9Zdris5Z22haR2xIhj?50X50&imageView2/1/w/50/h/50"}/>
            <p>学烘培</p></div>)
    }

}

export default home;